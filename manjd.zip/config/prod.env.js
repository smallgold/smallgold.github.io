'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://system.manjd.com"', // 配置为本地地址才会访问到本地虚拟的服务器
  DOMAIN: '"manjd.com"' // 设置请求地址的domain
}
