import { post } from '@/utils/http'
import configs from '@/utils/configs'
import { getCookie, setCookie, removeCookie } from '@/utils/cookie'

const TokenKey = process.env.DOMAIN

function getToken () {
  return getCookie(TokenKey)
}

function setToken (token) {
  return setCookie(TokenKey, 'EEC31DE64A2AD41B374B0B0666F4C916FD01EB8CF5C925C18C9384197A3353F9D23DE79B3C056F0C2A0210A8BF868FDC9B89D27BE3905BB9867267AB278B203A32178F63DFB8EC91029A1D6A7AD6E8AC44519F5B8AC788F13A07A9386A158A99F2883D0E')
}

function removeToken () {
  return removeCookie(TokenKey)
}

const user = {
  state: {
    user: '',
    status: '',
    code: '',
    token: getToken(),
    name: '',
    avatar: '',
    introduction: '',
    roles: [],
    setting: {
      articlePlatform: []
    }
  },

  mutations: {
    SET_CODE: (state, code) => {
      state.code = code
    },
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_INTRODUCTION: (state, introduction) => {
      state.introduction = introduction
    },
    SET_SETTING: (state, setting) => {
      state.setting = setting
    },
    SET_STATUS: (state, status) => {
      state.status = status
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    }
  },

  actions: {
    // 用户名登录
    LoginByUsername ({ commit }, userInfo) {
      const username = userInfo.userAccount.trim()
      return new Promise((resolve, reject) => {
        post(configs.user['Login'], {
          userAccount: username,
          userPwd: userInfo.userPwd
        }).then((response) => {
          commit('SET_TOKEN', response.token)
          setToken(response.token)
          resolve(response)
        }).catch(error => {
          reject(error)
        })
        /* login(username, userInfo.userPwd).then(response => {
          commit('SET_TOKEN', response.token)
          setToken(response.token)
          resolve(response)
        }).catch(error => {
          reject(error)
        }) */
      })
    },

    // 登出
    LogOut ({ commit, state }) {
      return new Promise((resolve, reject) => {
        /* logout(state.token).then(() => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          removeToken()
          resolve()
        }).catch(error => {
          reject(error)
        }) */
      })
    },

    // 前端 登出
    FedLogOut ({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        removeToken()
        resolve()
      })
    },

    // 动态修改权限
    ChangeRoles ({ commit, dispatch }, role) {
      return new Promise(resolve => {
        commit('SET_TOKEN', role)
        setToken(role)
        /* getUserInfo(role).then(response => {
          const data = response.data
          commit('SET_ROLES', data.roles)
          commit('SET_NAME', data.name)
          commit('SET_AVATAR', data.avatar)
          commit('SET_INTRODUCTION', data.introduction)
          dispatch('GenerateRoutes', data) // 动态修改权限后 重绘侧边菜单
          resolve()
        }) */
      })
    }
  }
}

export default user
