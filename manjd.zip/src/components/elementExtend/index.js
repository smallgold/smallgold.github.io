import Vue from 'vue'
import mjbTable from './mjbTable.js'
Vue.component('mjbTable', mjbTable)
