<template>
  <div >
    404
  </div>
</template>

<script>
export default {
  name: 'default',
  data () {
    return {
    }
  }
}
</script>

<style lang="scss" scoped>
</style>
