<template>
  <div >
    欢迎来到满金坝管理系统！
  </div>
</template>
<script>
export default {
  name: 'default',
  data () {
    return {
    }
  },
  mounted () {
  }
}
</script>

<style lang="scss" scoped>
</style>
